package kz.iitu.salary;

public enum EmployeeType {
    Salaried, Hourly, Comission, Salaried_Comission
}
