package kz.iitu.salary;

public interface IEmployees {

}
